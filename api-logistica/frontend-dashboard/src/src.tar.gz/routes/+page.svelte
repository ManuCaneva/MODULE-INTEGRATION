<script>
  import Dashboard from '$lib/components/dashboard/Dashboard.svelte'
</script>

<svelte:head>
  <title>Dashboard</title>
</svelte:head>

<Dashboard />